<?php 

echo " Insert this shortcode wherever you want PayPal Donation: [donate]My Text Here[/donate]";